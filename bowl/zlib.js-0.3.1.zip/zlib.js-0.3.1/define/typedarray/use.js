/**
 * typed array defines
 */

goog.provide('USE_TYPEDARRAY');

/** @define {boolean} use typed array flag. */
var USE_TYPEDARRAY = true;

