goog.require('Zlib.RawInflateStream');

goog.exportSymbol('Zlib.RawInflateStream', Zlib.RawInflateStream);
goog.exportSymbol(
  'Zlib.RawInflateStream.prototype.decompress',
  Zlib.RawInflateStream.prototype.decompress
);
