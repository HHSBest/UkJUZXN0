goog.require('Zlib.Gunzip');

goog.exportSymbol('Zlib.Gunzip', Zlib.Gunzip);
goog.exportSymbol(
  'Zlib.Gunzip.prototype.decompress',
  Zlib.Gunzip.prototype.decompress
);
goog.exportSymbol(
  'Zlib.Gunzip.prototype.getMembers',
  Zlib.Gunzip.prototype.getMembers
);
