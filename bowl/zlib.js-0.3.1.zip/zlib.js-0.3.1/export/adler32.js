goog.require('Zlib.Adler32');

goog.exportSymbol('Zlib.Adler32', Zlib.Adler32);
goog.exportSymbol('Zlib.Adler32.update', Zlib.Adler32.update);
